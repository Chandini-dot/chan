import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-today',
  templateUrl: './today.component.html',
  styleUrls: ['./today.component.css']
})
export class TodayComponent implements OnInit {
  public data2

  constructor() { }

  ngOnInit() {
    this.data2=JSON.parse(localStorage.getItem('newsData'))
    console.log(this.data2)
  }

}


