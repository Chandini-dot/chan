import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public a1;
  public api
  
 ​
   public ids = []
   public totalData = []
  constructor(private http: HttpClient, private router: Router) { }
​
  ngOnInit() {
    this.http.get('https://jvapi.peelpress.com/news').subscribe(data => {
      console.log(data)
  
      this.api = data['news']
      for (var i = 0; i < this.api.length; i++) {
        this.ids.push(this.api[i]._id)
      }
      console.log(this.api, this.ids)
    })
    setTimeout(() => {​
​
      for (var j = 0; j < this.ids.length; j++) {
        this.http.get('https://jvapi.peelpress.com/news/' + this.ids[j]).subscribe(data => {
          console.log(data)
          this.totalData.push(data['news'])
          console.log(this.totalData)
        })
      }
    }, 2000);
  }
  new(){
    this.router.navigateByUrl('log')
  }
  tonextPage(data) {
    console.log('11', data)
    localStorage.setItem('newsData', JSON.stringify(data))
    this.router.navigate(['today'])
  }
}

